import java.util.Scanner;

public class Main {

	public static void remove(String str1, String str2) {
		String strnew1 = "";
		String strnew2 = "";
		int l1 = str1.length();
		int l2 = str2.length();
		for (int j = 0; j < l1; j++) {
			char ch1 = str1.charAt(j);
			boolean isMatched = false;
			for (int p = 0; p < l2; p++) {
				char ch2 = str2.charAt(p);
				if (ch1 == ch2) {
					isMatched = true;
					break;
				}

			}
			if (!isMatched) {

				strnew1 += ch1;

			}

		}

		for (int j = 0; j < l2; j++) {
			char ch2 = str2.charAt(j);
			boolean isMatched = false;
			for (int p = 0; p < l1; p++) {
				char ch1 = str1.charAt(p);
				if (ch2 == ch1) {
					isMatched = true;
					break;
				}

			}
			if (!isMatched) {
				strnew2 += ch2;

			}

		}
		if (strnew1.isBlank())
			strnew1 = null;
		if (strnew2.isBlank())
			strnew2 = null;
		System.out.println("Output 1 " + strnew1);
		System.out.println("Output 2 " + strnew2);

	}

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);

		System.out.println("Enter first String: ");
		String str1 = scanner.nextLine();
		str1.trim();
		System.out.println("Enter Second String: ");
		String str2 = scanner.nextLine();

		str2.trim();
		Main.remove(str1, str2);

		scanner.close();

	}

}
